# TvLauncher — Launcher personnalisé pour Google TV / Android TV

## Build
1. Ouvrir le dossier dans **Android Studio** (Gradle sync automatique).
2. Build > Build APK(s)  → `app/build/outputs/apk/debug/app-debug.apk`

## Installer sur la TV
1. TV: Paramètres > Système > À propos > cliquer 7× sur "Build" (mode développeur),
   puis activer **Débogage USB/réseau**.
2. Sur PC: `adb connect IP_DE_LA_TV:5555`
3. `adb install app-debug.apk`

## Le définir comme écran d'accueil
Appuyer sur Home: Android propose de choisir le launcher. Sur Google TV, le
launcher d'origine est souvent imposé; si aucun choix n'apparaît :
`adb shell pm disable-user --user 0 com.google.android.apps.tv.launcherx`
(pour revenir en arrière: `adb shell pm enable com.google.android.apps.tv.launcherx`)
Le nom du package peut varier selon la marque (Orange TV, etc.).

## Personnaliser
Tout est dans `MainActivity.kt` : `heroCards`, `playlists` (liens Spotify), couleurs,
horloge, dock. Pour de vraies images, ajouter la librairie Coil.
