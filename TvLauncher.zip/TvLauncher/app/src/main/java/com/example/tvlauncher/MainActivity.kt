package com.example.tvlauncher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherScreen() }
    }

    // Home button: stay on this screen instead of stacking
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* launcher: ignore back */ }
}

/* ------------------------- DATA (edit freely) ------------------------- */

data class HeroCard(
    val tag: String, val title: String, val subtitle: String,
    val colors: List<Color>, val uri: String
)

data class Playlist(val title: String, val color: Color, val uri: String)

val heroCards = listOf(
    HeroCard("EN CONCERT", "The Weeknd", "Live au Stade de France",
        listOf(Color(0xFF3A4A66), Color(0xFF111827)), "spotify:search:The%20Weeknd"),
    HeroCard("STUDIO", "SCH", "Train Mistral · Clip officiel",
        listOf(Color(0xFF7B2FBE), Color(0xFF1B0B3A)), "spotify:search:SCH%20Train%20Mistral"),
    HeroCard("CLIP", "Morgan Wallen", "Sand in My Boots · Sessions",
        listOf(Color(0xFF4B5563), Color(0xFF0B0F17)), "spotify:search:Morgan%20Wallen"),
)

val playlists = listOf(
    Playlist("Today's Top Hits", Color(0xFFE11D74), "spotify:playlist:37i9dQZF1DXcBWIGoYBM5M"),
    Playlist("Top 50 France", Color(0xFF2563EB), "spotify:playlist:37i9dQZEVXbIPWwFssbupI"),
    Playlist("Hot Country", Color(0xFFB45309), "spotify:playlist:37i9dQZF1DX1lVhptIYRda"),
    Playlist("Top 50 Monde", Color(0xFF0D9488), "spotify:playlist:37i9dQZEVXbMDoHDwVN2tF"),
)

data class AppItem(val label: String, val icon: ImageBitmap, val intent: Intent)

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    fun query(cat: String) = pm.queryIntentActivities(
        Intent(Intent.ACTION_MAIN).addCategory(cat), 0
    )
    val infos = (query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER))
        .distinctBy { it.activityInfo.packageName }
        .filter { it.activityInfo.packageName != ctx.packageName }
    return infos.mapNotNull { ri ->
        val pkg = ri.activityInfo.packageName
        val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
            ?: pm.getLaunchIntentForPackage(pkg) ?: return@mapNotNull null
        AppItem(
            ri.loadLabel(pm).toString(),
            ri.loadIcon(pm).toBitmap(160, 160).asImageBitmap(),
            launch
        )
    }.sortedBy { it.label.lowercase() }
}

fun openUri(ctx: Context, uri: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) { /* Spotify not installed */ }
}

/* ------------------------------- UI ----------------------------------- */

@Composable
fun LauncherScreen() {
    val ctx = LocalContext.current
    val apps = remember { loadApps(ctx) }

    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF0B0B14), Color(0xFF2A1250), Color(0xFF0B0B14)))
        )
    ) {
        Clock(Modifier.align(Alignment.TopEnd).padding(32.dp))

        Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 32.dp)) {
            Spacer(Modifier.height(56.dp))

            // Hero cards
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                heroCards.forEach { c ->
                    FocusCard(Modifier.weight(1f).height(210.dp), onClick = { openUri(ctx, c.uri) }) {
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(c.colors)).padding(16.dp)) {
                            Text(c.tag, color = Color.White.copy(0.8f), fontSize = 11.sp,
                                modifier = Modifier.align(Alignment.TopStart))
                            Column(Modifier.align(Alignment.BottomStart)) {
                                Text(c.subtitle, color = Color.White.copy(0.7f), fontSize = 12.sp)
                                Text(c.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Playlists populaires", color = Color.White.copy(0.8f), fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                playlists.forEach { p ->
                    FocusCard(Modifier.weight(1f).height(64.dp), onClick = { openUri(ctx, p.uri) }) {
                        Row(Modifier.fillMaxSize().background(Color.White.copy(0.06f)).padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(p.color))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(p.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("Playlist · Spotify", color = Color.White.copy(0.6f), fontSize = 10.sp)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            // App dock
            LazyRow(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.Bottom
            ) {
                items(apps) { app -> AppIcon(app) { ctx.startActivity(app.intent) } }
            }
        }
    }
}

@Composable
fun Clock(modifier: Modifier = Modifier) {
    val now by produceState(Date()) {
        while (true) { value = Date(); delay(1000) }
    }
    Column(modifier, horizontalAlignment = Alignment.End) {
        Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now),
            color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now),
            color = Color.White.copy(0.7f), fontSize = 12.sp)
    }
}

@Composable
fun FocusCard(modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.06f else 1f, label = "scale")
    Box(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(18.dp))
            .border(if (focused) 3.dp else 0.dp, Color.White, RoundedCornerShape(18.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
    ) { content() }
}

@Composable
fun AppIcon(app: AppItem, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.25f else 1f, label = "scale")
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            bitmap = app.icon, contentDescription = app.label,
            modifier = Modifier
                .size(64.dp).scale(scale)
                .clip(RoundedCornerShape(16.dp))
                .border(if (focused) 3.dp else 0.dp, Color.White, RoundedCornerShape(16.dp))
                .onFocusChanged { focused = it.isFocused }
                .clickable(onClick = onClick)
        )
        Spacer(Modifier.height(6.dp))
        Text(if (focused) app.label else " ", color = Color.White, fontSize = 12.sp, maxLines = 1)
    }
}
